This description of the LabVIEW driver for the Keithley Model 6517A
Electrometer will guide you in the best use of the driver.
Although this driver was written to cover most of the features of the
Electrometer, it does not cover 100% of all of the features and potential
uses of the Electrometer. Keithley Instruments, Inc. does not guarantee that
the driver will work in every situation and application.

The LabVIEW driver itself has built-in help functions which contain details
on all of the functions for each VI. These help functions can assist you when
developing your LabVIEW applications with the 6517A Electrometer.

Listed below are the LabVIEW VI's available and their functions:

GPIB Receive Message.VI : This VI can be used to return data from the
    Electrometer. The VI requires that an address be provided. You can also
    select the type of termination function that the VI will halt data
    transfer from the bus.

GPIB Send Message.VI: This VI can be used to send any SCPI command to
    the Electrometer. If there is any function you would like to execute that
    is not part of the driver, you can use this VI to send the commands. You
    need to provide the GPIB Address and the command string.

Keithley 6517A Arm Config.VI: This VI is used to set the Arm layer of
    the Electrometer Trigger Model. Triggering can be set to Immediate,
    Manual, GPIB Bus, Trigger Link, External, and Real-Time Clock Trigger.
    These trigger events are used to start the measurement process of the
    Electrometer. Maximum count value for the Arm layer is 99999.

Keithley 6517A Arm2 Config.VI: This VI is used to set the Arm2 layer of
    the Electrometer Trigger Model. Triggering can be set to Immediate,
    Manual, GPIB Bus, Trigger Link, External, and Timer Trigger.
    These trigger events are used to trigger the scanning layer of the
    Electrometer. Maximum count value for the Arm layer is 99999.

Keithley 6517A Buffer Config.VI: This VI is used to set up the
    Electrometer internal data buffer for data storage. The maximum number
    of readings that can be stored is 15706. Control of the timestamp is
    also set here, either Absolute or Delta. Setting the Buffer Control
    to NEXT arms the internal data buffer to store readings. This VI
    allows you to clear the buffer as well as configure it for storing
    readings. This VI also control how pretriggering will function.
    In this VI, you also specify which additional buffer elements are
    stored in the buffer, specifically, the Scanning Channel Element, the
    External Temperature measurements, Humidity measurements, timestamp data
    and the Voltage Source value.

Keithley 6517A Buffer Math Config.VI: This VI instructs the Electrometer
    to perform a specific math operation on data stored in the internal
    data buffer. Choices include MEAN, STANDARD DEVIATION, MAX, MIN, and
    PEAK to PEAK.

Keithley 6517A Buffer Read.VI: This VI is used to transfer data across
    the bus from measurements stored in the internal data buffer. The VI
    will return the actual number of readings actually stored in the buffer,
    the data format used for the data transfer, the data elements stored
    in the buffer, and the actual data which is stored in a LabVIEW array.
    The data elements returned can be configured using the Data Format VI.
    Typical data transfer times from the buffers are as follows:

		7 elements, 5944 readings, type ASCII = 300 seconds
		4 elements, 8646 readings, type ASCII = 360 seconds
		1 elements, 15853 readings, type ASCII = 120 seconds
		7 elements, 5944 readings, type SREAL = 19 seconds
		4 elements, 8646 readings, type SREAL = 30 seconds
		1 elements, 15853 readings, type SREAL = 11 seconds

    These benchmarks were tested using a National Instruments AT-GPIB card
    on a Gateway G6-200 Computer. Clearly using the VI in Binary data
    transfer mode offers the fastest  transfer rates from the buffer.
    We strongly recommend the use of the internal data buffer of the
    Electrometer for the best performance. Reading rates and storage into
    the buffer will depend on how the Electrometer is set up for making
    measurements. Items like integration rate, filtering, display modes,
    and autoranging can affect reading rates but not how fast data is
    transferred out of the buffer across the bus.

Keithley 6517A Coulombs Config.VI: This VI is used to configure the
    6517A for charge measurements. The VI allows you to set the measurement
    range, the Integration rate (NPLC), resolution, and filter values.

Keithley 6517A Data Format.VI: This VI allows the user to specify which
    reading elements to return across the bus (Channel, Reading Number, Units
    Timestamp, Status, External Temperature, Humidity, and Vsource) and how 
    the data will be transferred (ASCII or SEAL). 

    The VI allows you to choose how the binary SREAL data is configured for
    transfer, specifically a SWAPPED binary order or a NORMAL binary order.
    Please refer to the Model 6517A Users Manual for more details on Binary
    Byte Order.

    If you are using the internal data buffer to store readings, selecting yes
    to the Buffered Data Elements removes the Units and Status elements to be
    stored in the buffer.

Keithley 6517A DCI Measure Config.VI: This VI is used to configure the
    6517A for Current measurements. The VI allows you to set the measurement
    range, the Integration rate (NPLC), resolution, and filter values.

Keithley 6517A DCV Measure Config.VI: This VI is used to configure the
    6517A for Voltage measurements. The VI allows you to set the measurement
    range, the Integration rate (NPLC), resolution, and filter values.

Keithley 6517A Display Config.VI: This VI is used to configure and control
    the front panel display. This VI can be used to display user defined
    message text on the primary and secondary display lines. The VI is
    also used to control the resolution of the displayed measurements.

Keithley 6517A Display Read.VI: This VI is used to return string
    value equivalents of what is displayed on the primary and secondary
    display lines of the front panel display. This VI is good to use when
    you want the contents of the secondary display line which is not
    normally transferred across the bus.

Keithley 6517A Error Reader.VI: This VI is used to query the 6517A
    Electrometer for error messages in the error queue.

Keithley 6517A Initialize.VI: This VI puts the 6517A Electrometer into a
    known reset state. The VI sets the parameters of the GPIB Interface for
    Re-Addressing, Assert REN and system controller. You should run this
    VI before using any of the other VI's.

Keithley 6517A Limits Config.VI: This VI is used to set up the internal
    limits functions of the 6517A Electrometer. The limits are used for
    pass/fail testing of measurements Please refer to the 6517A Users Manual
    for full details on the use of the limits operations. Please note the
    limits are a main part of the operation when the 6517A Electrometer is
    used with a component handler.

Keithley 6517A Math Config.VI: This VI is used to set the math functions
    to be applied to measurements. Math functions include Percent, Polynomial,
    Ratio, Deviation, and % Deviation. Where applicable, parameters for the
    selected math funcitons are available to be set.

Keithley 6517A Math Read.VI: This VI is used to read the results of
    selected math calculations of the Electrometer. These math calculations
    include math calculations, limit calculations and buffer math
    operations. Math calculations are configured using the Math Config,
    Limits Config, and Buffer Math Config VI's.

Keithley 6517A Measure Query.VI: This VI queries the 6517A for a single
    reading depending on which function is set. This VI uses the
    MEASURE:<function>? SCPI Signal Oriented command to take measurements.
    You must turn ZERO CHECK off before using this VI using the ZERO CHECK VI.

Keithley 6517A Reset/Preset.VI: This VI allows the user to send a 'hard
    reset' or 'power-up' reset to the Electrometer. Refer to the 6517A Users
    Manual for complete description on resetting the Electrometer and the
    settings of the Electrometer after the reset is completed.

Keithley 6517A Resistance Config.VI: This VI is used to configure the
    6517A for Resistance measurements. The VI allows you to set the measurement
    range, the Integration rate (NPLC), resolution, and filter values.

Keithley 6517A Scan Config.VI: This VI is used to select the scanning method
    to be used including Voltage or Current scanning. The user can select
    the scanning settling time and whether the Vsource Limit is set to 200V

Keithley 6517A Scanner Control.VI: This VI offers ways to set up the 6517A for
    internal scanning. You can open all channels, open a single channel, close 
    a single channel, or set up a scanning list.

Keithley 6517A Single Read Example.VI: This VI is a simple EXAMPLE showing
    how some of the 6517A VI's are combine to make a single measurement and
    return the data adn display the data.

Keithley 6517A System Functions.VI: This VI is used to execute some of
    the basic system operations. These commands are optional and do not
    need to be performed for any specified type of measurement. This VI
    allows you to:
	Reset the Reading Number to 0
	Reset the Relative Timestamp value to 0
	Save 6517A configurations
	Recall 6517A configurations
	Set the power-on state
	Set the Line-syncing controls
	Set the real-time Time and Date
	Select the timestamp type
	Control the external temperature function
	Control the A/D hardware limit
	Control the Humidity reading function

Keithley 6517A Trigger Control.VI: : This VI is used to set the Trigger
    layer of the Electrometer Trigger Model. Triggering can be set to Immediate,
    Manual, GPIB Bus, Trigger Link, External, and Timer Trigger.
    These trigger events are used to trigger the measure layer of the
    Electrometer. Maximum count value for the Arm layer is 99999.

Keithley 6517A TTL Output.VI: This VI is used to control the 4 digital output
    lines of the instrument. The polarity can be see to active high or
    active low and the channels can be turned on or off on an individual
    basis.

Keithley 6517A V-Source Output.VI: This VI is used to set the Built-In Voltage 
    Source. The user can select either a +/- 100 Volt range or a +/- 1000 Volt range. 
    The desired output can be selected and the output can be turned on or off. Note 
    that if the range is set for +/- 100 V and the selected output voltage is greater 
    than 100 volts, the output will clamp at 100 volts. To get a voltage higher than 
    100, you must select the +/-1000 volt range.

	Vsource Control Selection:
		Set Vsource Output On/Off State
		Set Vsource Range and Output Level
		Set Vsource Voltage Limit and State
		Enable Measure Connect
		Disable Measure Connect
		Set Resistive Current Limit State

Keithley 6517A Zero Check.VI: This VI is used to control the ZERO CHECK function
    of the 6517A.


In addition to the main LabVIEW VI's for the 6517A, there is an extended group of VI's
that perform the 6517A Test Sequences. The file is 'TEST_SEQ.LLB'. This VI group
contains VI's to perform the following built-in test sequences:

	Cable Insulation Resistance
	Capacitor Leakage
	Diode Leakage
	Resistor Voltage Coefficient
	SIR (Surface Insulation Resistance)
	Staircase Sweep
	Square Wave Sweep
	Surface Resistivity (non-Alternating Polarity Method)
	Volume Resistivity (non-Alternating Polarity Method)

For more details on the test sequences, refer to the 6517A Users Manual.
	

KEITHLEY INSTRUMENTS DOES NOT PROVIDE TECHNICAL SUPPORT FOR LABVIEW
SOFTWARE. KEITHLEY INSTRUMENTS CAN OFFER ADVICE ON HOW TO BEST USE THE
6517A ELECTROMETER PRODUCT. FOR TECHNICAL SUPPORT ON THE 6517A ELECTROMETER, 
PLEASE CALL THE KEITHLEY INSTRUMENTS APPLICATIONS DEPARTMENT AT 800-348-3735 
(US AND CANADA ONLY) OUTSIDE OF THE UNITED STATES, PLEASE CONTACT YOUR LOCAL 
KEITHLEY OFFICE OR SALES REPRESENTATIVE.

